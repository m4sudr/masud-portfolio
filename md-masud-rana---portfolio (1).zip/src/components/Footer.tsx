import { Facebook, Linkedin, Instagram, ArrowUp, Github } from 'lucide-react';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-dark-surface border-t border-white/10 pt-16 pb-8 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 mb-12">
          <div className="text-center md:text-left">
            <h2 className="text-2xl font-display font-bold text-white mb-2 tracking-wider">
              MASUD<span className="text-neon-blue">.R</span>
            </h2>
            <p className="text-gray-400 font-medium">Washing Production Reporter</p>
            <p className="text-gray-500 text-sm mt-1">Dhaka, Bangladesh</p>
          </div>

          <div className="flex items-center gap-6">
            <a
              href="https://www.facebook.com/share/17f2vfKBu5/"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-full bg-dark-bg border border-white/10 flex items-center justify-center text-gray-400 hover:text-neon-blue hover:border-neon-blue hover:shadow-[0_0_15px_rgba(0,243,255,0.3)] transition-all duration-300"
            >
              <Facebook size={20} />
            </a>
            <a
              href="https://bd.linkedin.com/in/masud-hasan-7500b51a1"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-full bg-dark-bg border border-white/10 flex items-center justify-center text-gray-400 hover:text-neon-cyan hover:border-neon-cyan hover:shadow-[0_0_15px_rgba(0,255,255,0.3)] transition-all duration-300"
            >
              <Linkedin size={20} />
            </a>
            <a
              href="https://www.instagram.com/m4sud404"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-full bg-dark-bg border border-white/10 flex items-center justify-center text-gray-400 hover:text-pink-500 hover:border-pink-500 hover:shadow-[0_0_15px_rgba(236,72,153,0.3)] transition-all duration-300"
            >
              <Instagram size={20} />
            </a>
            <a
              href="https://wa.me/8801638098059"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-full bg-dark-bg border border-white/10 flex items-center justify-center text-gray-400 hover:text-green-500 hover:border-green-500 hover:shadow-[0_0_15px_rgba(34,197,94,0.3)] transition-all duration-300"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/>
              </svg>
            </a>
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-full bg-dark-bg border border-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:border-white hover:shadow-[0_0_15px_rgba(255,255,255,0.3)] transition-all duration-300"
            >
              <Github size={20} />
            </a>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-500 text-sm">
            Copyright © 2026 Md Masud Rana. All Rights Reserved.
          </p>
          
          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 text-sm text-gray-400 hover:text-neon-blue transition-colors"
          >
            Back to Top
            <ArrowUp size={16} />
          </button>
        </div>
      </div>
    </footer>
  );
}
