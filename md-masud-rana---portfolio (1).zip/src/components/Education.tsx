import { motion } from 'motion/react';
import { GraduationCap, School } from 'lucide-react';

const educationData = [
  {
    degree: 'Diploma in Mechanical Engineering',
    institution: 'Mymensingh Polytechnic Institute',
    department: 'Mechanical Engineering',
    icon: <GraduationCap size={24} />,
  },
  {
    degree: 'Secondary School Certificate (SSC)',
    institution: 'D.K. Islamia High School',
    passingYear: '2017',
    icon: <School size={24} />,
  },
];

export default function Education() {
  return (
    <section id="education" className="py-24 bg-dark-surface relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">
            My <span className="text-neon-blue">Education</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-neon-blue to-neon-cyan mx-auto rounded-full" />
        </motion.div>

        <div className="relative max-w-3xl mx-auto">
          {/* Timeline Line */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-0.5 bg-white/10 transform md:-translate-x-1/2" />

          <div className="space-y-12">
            {educationData.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className={`relative flex flex-col md:flex-row items-center ${
                  index % 2 === 0 ? 'md:flex-row-reverse' : ''
                }`}
              >
                {/* Timeline Dot */}
                <div className="absolute left-8 md:left-1/2 w-12 h-12 rounded-full bg-dark-surface border-2 border-neon-blue flex items-center justify-center text-neon-blue transform -translate-x-1/2 z-10 shadow-[0_0_15px_rgba(0,243,255,0.3)]">
                  {item.icon}
                </div>

                {/* Content Card */}
                <div className={`w-full md:w-1/2 pl-20 md:pl-0 ${index % 2 === 0 ? 'md:pr-16 text-left md:text-right' : 'md:pl-16 text-left'}`}>
                  <div className="glass-card p-6 rounded-2xl hover:neon-border transition-all duration-300">
                    <h3 className="text-xl font-display font-bold text-white mb-2">{item.degree}</h3>
                    <h4 className="text-neon-cyan font-medium mb-3">{item.institution}</h4>
                    {item.department && (
                      <p className="text-gray-400 text-sm">Department: {item.department}</p>
                    )}
                    {item.passingYear && (
                      <p className="text-gray-400 text-sm">Passing Year: {item.passingYear}</p>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
