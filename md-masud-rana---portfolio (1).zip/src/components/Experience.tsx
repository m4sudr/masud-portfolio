import { motion } from 'motion/react';
import { Briefcase, Activity, FileText } from 'lucide-react';

const experienceData = [
  {
    title: 'Production Reporter',
    company: 'Natural Washing Plant Ltd',
    period: '2021 – Present',
    responsibilities: [
      'Production reporting and monitoring',
      'Denim washing process tracking',
      'Production data analysis',
    ],
    icon: <Activity size={24} />,
  },
  {
    title: 'Production Reporter',
    company: 'Wash & Wear Ltd',
    period: '2019 – 2021',
    responsibilities: [
      'Factory production reporting',
      'Data recording and workflow coordination',
    ],
    icon: <FileText size={24} />,
  },
  {
    title: 'Account Manager',
    company: 'Crispicy Mini Chinese',
    period: '2018 – 2019',
    responsibilities: [
      'Business operations management',
      'Customer service and financial reporting',
    ],
    icon: <Briefcase size={24} />,
  },
];

export default function Experience() {
  return (
    <section id="experience" className="py-24 bg-dark-bg relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">
            Work <span className="text-neon-cyan">Experience</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-neon-blue to-neon-cyan mx-auto rounded-full" />
        </motion.div>

        <div className="relative max-w-4xl mx-auto">
          {/* Timeline Line */}
          <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-0.5 bg-white/10 transform md:-translate-x-1/2" />

          <div className="space-y-12">
            {experienceData.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className={`relative flex flex-col md:flex-row items-center ${
                  index % 2 === 0 ? 'md:flex-row-reverse' : ''
                }`}
              >
                {/* Timeline Dot */}
                <div className="absolute left-8 md:left-1/2 w-12 h-12 rounded-full bg-dark-surface border-2 border-neon-cyan flex items-center justify-center text-neon-cyan transform -translate-x-1/2 z-10 shadow-[0_0_15px_rgba(0,255,255,0.3)]">
                  {item.icon}
                </div>

                {/* Content Card */}
                <div className={`w-full md:w-1/2 pl-20 md:pl-0 ${index % 2 === 0 ? 'md:pr-16 text-left md:text-right' : 'md:pl-16 text-left'}`}>
                  <div className="glass-card p-6 rounded-2xl hover:neon-border transition-all duration-300">
                    <h3 className="text-xl font-display font-bold text-white mb-2">{item.title}</h3>
                    <h4 className="text-neon-blue font-medium mb-1">{item.company}</h4>
                    <p className="text-sm text-gray-400 mb-4 font-mono">{item.period}</p>
                    <ul className={`space-y-2 text-gray-300 ${index % 2 === 0 ? 'md:text-right' : 'text-left'}`}>
                      {item.responsibilities.map((resp, i) => (
                        <li key={i} className={`flex items-start gap-2 ${index % 2 === 0 ? 'md:flex-row-reverse' : ''}`}>
                          <span className="text-neon-cyan mt-1">•</span>
                          <span>{resp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
