import { motion } from 'motion/react';
import { Factory, Database, PenTool, Smartphone, Activity, BarChart, Layout, Share2 } from 'lucide-react';

const skillCategories = [
  {
    title: 'Industrial Skills',
    icon: <Factory size={28} className="text-neon-blue" />,
    skills: [
      { name: 'Production Reporting', level: 90 },
      { name: 'Denim Washing Process', level: 85 },
      { name: 'Factory Workflow Monitoring', level: 88 },
      { name: 'Production Planning', level: 80 },
    ],
  },
  {
    title: 'Technical Skills',
    icon: <Database size={28} className="text-neon-cyan" />,
    skills: [
      { name: 'Data Analysis', level: 75 },
      { name: 'App Development (Beginner)', level: 40 },
      { name: 'Digital Systems Management', level: 70 },
    ],
  },
  {
    title: 'Creative Skills',
    icon: <PenTool size={28} className="text-neon-blue" />,
    skills: [
      { name: 'Content Creation', level: 80 },
      { name: 'Graphic Design', level: 75 },
      { name: 'Social Media Content', level: 85 },
    ],
  },
];

export default function Skills() {
  return (
    <section id="skills" className="py-24 bg-dark-surface relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">
            My <span className="text-neon-blue">Skills</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-neon-blue to-neon-cyan mx-auto rounded-full" />
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {skillCategories.map((category, catIndex) => (
            <motion.div
              key={catIndex}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: catIndex * 0.2 }}
              className="glass-card p-8 rounded-2xl hover:neon-border transition-all duration-300"
            >
              <div className="flex items-center gap-4 mb-8">
                <div className="p-3 bg-white/5 rounded-xl border border-white/10">
                  {category.icon}
                </div>
                <h3 className="text-xl font-display font-bold text-white">{category.title}</h3>
              </div>

              <div className="space-y-6">
                {category.skills.map((skill, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium text-gray-300">{skill.name}</span>
                      <span className="text-sm font-mono text-neon-cyan">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-dark-bg rounded-full h-2 overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 1, delay: 0.5 + index * 0.1 }}
                        className="h-2 rounded-full bg-gradient-to-r from-neon-blue to-neon-cyan relative"
                      >
                        <div className="absolute top-0 right-0 bottom-0 w-4 bg-white/30 blur-[2px]" />
                      </motion.div>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
