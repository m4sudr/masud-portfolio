import { motion } from 'motion/react';
import { ExternalLink, Github } from 'lucide-react';

const projectsData = [
  {
    title: 'Production Reporting System Concept',
    description: 'A digital concept for tracking factory production, washing stages, and daily output reports.',
    category: 'Data Management',
    image: 'https://picsum.photos/seed/dashboard/600/400',
  },
  {
    title: 'Denim Washing Process Guide',
    description: 'A visual documentation project explaining different denim washing techniques.',
    category: 'Documentation',
    image: 'https://picsum.photos/seed/denim/600/400',
  },
  {
    title: 'Mobile App Concept for Production Tracking',
    description: 'A conceptual Android application idea to help factory supervisors track production progress.',
    category: 'App Development',
    image: 'https://picsum.photos/seed/mobileapp/600/400',
  },
  {
    title: 'Creative Content Projects',
    description: 'Design and video content created for social media platforms.',
    category: 'Content Creation',
    image: 'https://picsum.photos/seed/design/600/400',
  },
];

export default function Projects() {
  return (
    <section id="projects" className="py-24 bg-dark-surface relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">
            Featured <span className="text-neon-blue">Projects</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-neon-blue to-neon-cyan mx-auto rounded-full" />
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {projectsData.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="glass-card rounded-2xl overflow-hidden group hover:neon-border transition-all duration-300"
            >
              <div className="relative h-64 overflow-hidden">
                <div className="absolute inset-0 bg-neon-blue/20 mix-blend-overlay z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 right-4 z-20">
                  <span className="px-3 py-1 bg-dark-bg/80 backdrop-blur-md text-neon-cyan text-xs font-mono rounded-full border border-neon-cyan/30">
                    {project.category}
                  </span>
                </div>
              </div>
              <div className="p-8">
                <h3 className="text-2xl font-display font-bold text-white mb-3 group-hover:text-neon-blue transition-colors">
                  {project.title}
                </h3>
                <p className="text-gray-400 mb-6 leading-relaxed">
                  {project.description}
                </p>
                <div className="flex gap-4">
                  <button className="flex items-center gap-2 text-sm font-medium text-white hover:text-neon-cyan transition-colors">
                    <ExternalLink size={18} />
                    View Details
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
