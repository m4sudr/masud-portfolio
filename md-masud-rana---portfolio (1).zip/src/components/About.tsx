import { motion } from 'motion/react';
import { Code, Cpu, PenTool, Smartphone } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-24 bg-dark-bg relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">
            About <span className="text-neon-cyan">Me</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-neon-blue to-neon-cyan mx-auto rounded-full" />
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            <h3 className="text-2xl font-display font-semibold text-white">Who I Am</h3>
            <p className="text-gray-400 leading-relaxed text-lg">
              Md Masud Rana is a production professional working in the denim washing industry. With a diploma in Mechanical Engineering and practical factory experience, he specializes in production monitoring, data reporting, and process efficiency.
            </p>

            <h3 className="text-2xl font-display font-semibold text-white mt-8">Career Focus</h3>
            <p className="text-gray-400 leading-relaxed text-lg">
              His work focuses on improving production efficiency in washing plants while also exploring technology-driven solutions.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="glass-card p-8 rounded-2xl"
          >
            <h3 className="text-2xl font-display font-semibold text-white mb-6">Personal Interests</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-neon-blue/10 rounded-lg text-neon-blue">
                  <Cpu size={24} />
                </div>
                <div>
                  <h4 className="text-white font-medium mb-1">Technology</h4>
                  <p className="text-sm text-gray-400">Software & digital systems</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-neon-cyan/10 rounded-lg text-neon-cyan">
                  <Smartphone size={24} />
                </div>
                <div>
                  <h4 className="text-white font-medium mb-1">App Dev</h4>
                  <p className="text-sm text-gray-400">Mobile app development</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-neon-blue/10 rounded-lg text-neon-blue">
                  <PenTool size={24} />
                </div>
                <div>
                  <h4 className="text-white font-medium mb-1">Design</h4>
                  <p className="text-sm text-gray-400">Graphic design</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-neon-cyan/10 rounded-lg text-neon-cyan">
                  <Code size={24} />
                </div>
                <div>
                  <h4 className="text-white font-medium mb-1">Content</h4>
                  <p className="text-sm text-gray-400">Digital content creation</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
