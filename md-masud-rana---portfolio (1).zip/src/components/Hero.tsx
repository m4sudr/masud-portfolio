import { motion } from 'motion/react';
import { ArrowRight, Mail, Facebook, Linkedin, Instagram, Github } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/industrial/1920/1080?blur=10')] opacity-20 bg-cover bg-center mix-blend-overlay" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-neon-blue/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-neon-cyan/20 rounded-full blur-[120px]" />
        
        {/* Grid pattern overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_80%_50%_at_50%_50%,black,transparent)]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="mb-8 relative"
        >
          <div className="w-40 h-40 md:w-56 md:h-56 rounded-full p-1 neon-border bg-dark-surface">
            <img
              src="https://i.ibb.co/sJw0DGNc/1770475511752.png"
              alt="Md Masud Rana"
              className="w-full h-full object-cover rounded-full border-2 border-transparent"
              referrerPolicy="no-referrer"
            />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <h2 className="text-neon-blue font-mono text-sm md:text-base mb-4 tracking-widest uppercase">
            Hello, I am
          </h2>
          <h1 className="text-5xl md:text-7xl font-display font-bold text-white mb-6 tracking-tight">
            Md Masud <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-blue to-neon-cyan">Rana</span>
          </h1>
          
          <div className="flex items-center justify-center gap-6 mb-8">
            <a
              href="https://www.facebook.com/share/17f2vfKBu5/"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-full bg-dark-bg border border-white/10 flex items-center justify-center text-gray-400 hover:text-neon-blue hover:border-neon-blue hover:shadow-[0_0_15px_rgba(0,243,255,0.3)] transition-all duration-300"
            >
              <Facebook size={20} />
            </a>
            <a
              href="https://bd.linkedin.com/in/masud-hasan-7500b51a1"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-full bg-dark-bg border border-white/10 flex items-center justify-center text-gray-400 hover:text-neon-cyan hover:border-neon-cyan hover:shadow-[0_0_15px_rgba(0,255,255,0.3)] transition-all duration-300"
            >
              <Linkedin size={20} />
            </a>
            <a
              href="https://www.instagram.com/m4sud404"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-full bg-dark-bg border border-white/10 flex items-center justify-center text-gray-400 hover:text-pink-500 hover:border-pink-500 hover:shadow-[0_0_15px_rgba(236,72,153,0.3)] transition-all duration-300"
            >
              <Instagram size={20} />
            </a>
            <a
              href="https://wa.me/8801638098059"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-full bg-dark-bg border border-white/10 flex items-center justify-center text-gray-400 hover:text-green-500 hover:border-green-500 hover:shadow-[0_0_15px_rgba(34,197,94,0.3)] transition-all duration-300"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/>
              </svg>
            </a>
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="w-12 h-12 rounded-full bg-dark-bg border border-white/10 flex items-center justify-center text-gray-400 hover:text-white hover:border-white hover:shadow-[0_0_15px_rgba(255,255,255,0.3)] transition-all duration-300"
            >
              <Github size={20} />
            </a>
          </div>

          <p className="text-base md:text-lg text-gray-400 max-w-2xl mx-auto mb-10 leading-relaxed">
            Passionate tech enthusiast and creative developer. I specialize in writing clean code, designing stunning graphics, and building intuitive mobile applications. Always exploring new technologies and contributing to projects on GitHub.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <a
            href="#projects"
            className="group flex items-center justify-center gap-2 px-8 py-4 bg-neon-blue text-dark-bg font-bold rounded-full hover:bg-neon-cyan transition-all duration-300"
          >
            View Portfolio
            <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
          </a>
          <a
            href="#contact"
            className="group flex items-center justify-center gap-2 px-8 py-4 bg-transparent border border-white/20 text-white font-bold rounded-full hover:bg-white/10 transition-all duration-300"
          >
            Contact Me
            <Mail size={20} />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
