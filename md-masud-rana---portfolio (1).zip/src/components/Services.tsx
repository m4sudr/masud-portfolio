import { motion } from 'motion/react';
import { Activity, Droplet, Database, Smartphone, PenTool, Video } from 'lucide-react';

const servicesData = [
  {
    title: 'Production Data Reporting',
    description: 'Monitoring factory production and generating detailed reports.',
    icon: <Activity size={32} />,
    color: 'neon-blue',
  },
  {
    title: 'Denim Washing Process Analysis',
    description: 'Understanding washing stages and improving workflow.',
    icon: <Droplet size={32} />,
    color: 'neon-cyan',
  },
  {
    title: 'Factory Data Management',
    description: 'Organizing production data and reporting systems.',
    icon: <Database size={32} />,
    color: 'neon-blue',
  },
  {
    title: 'Basic App Development',
    description: 'Developing simple tools or apps to help production reporting.',
    icon: <Smartphone size={32} />,
    color: 'neon-cyan',
  },
  {
    title: 'Graphic Design',
    description: 'Creating digital graphics for social media or branding.',
    icon: <PenTool size={32} />,
    color: 'neon-blue',
  },
  {
    title: 'Content Creation',
    description: 'Producing creative digital content including videos and graphics.',
    icon: <Video size={32} />,
    color: 'neon-cyan',
  },
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-dark-bg relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-display font-bold text-white mb-4">
            My <span className="text-neon-cyan">Services</span>
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-neon-blue to-neon-cyan mx-auto rounded-full" />
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {servicesData.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="glass-card p-8 rounded-2xl hover:neon-border transition-all duration-300 group"
            >
              <div className={`w-16 h-16 rounded-2xl bg-${service.color}/10 border border-${service.color}/20 flex items-center justify-center text-${service.color} mb-6 group-hover:scale-110 transition-transform duration-300`}>
                {service.icon}
              </div>
              <h3 className="text-xl font-display font-bold text-white mb-4">{service.title}</h3>
              <p className="text-gray-400 leading-relaxed">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
